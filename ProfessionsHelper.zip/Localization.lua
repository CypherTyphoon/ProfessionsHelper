-- Localization.lua
local L = {}
L["Leather"] = "Leder"        -- DE
L["Chitin"] = "Chitin"        -- DE
L["Hide"] = "Balg"
L["Armor"] = "Schuppen/Panzer"
L["Herbs"] = "Kräuter"
L["Ores"] = "Erze"

-- Zugriff:
print(L["Leather"])  -- gibt "Leder" aus
